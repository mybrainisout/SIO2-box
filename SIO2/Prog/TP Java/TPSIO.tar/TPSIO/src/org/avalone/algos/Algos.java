package org.avalone.algos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Algos {
	/**
	 * Cette classe contient tous les exercices d'algo codés
	 */
	private static final Scanner sc = new Scanner(System.in);
	
	public final static void clearConsole(){
	    try{
	        final String os = System.getProperty("os.name");

	        if (os.contains("Windows")){
	            Runtime.getRuntime().exec("cls");
	        }else{
	            Runtime.getRuntime().exec("clear");
	        }
	    }catch (final Exception e){
	    }
	}
	
	public static void main(String[] args) {
		int rep = 0;
		do{
			clearConsole();
			System.out.println("Liste des algorithmes disponibles :");
			System.out.println("Saisissez le numéro de celui désiré, ou 0 pour sortir.");
			System.out.println("1 - Nombres Premiers");
			System.out.println("2 - Année Bissextile");
			System.out.println("3 - Multiple de 3");
			System.out.println("4 - Multiples de 3 et de 5");
			System.out.println("5 - Fréquence de voyelles");
			System.out.println("6 - Palindrome");
			System.out.println("7 - Matrice négative");
			System.out.println("8 - Calculatrice");
			System.out.println("9 - Trie fichier CSV");
			System.out.println("0 - Sortir");
			System.out.print("Sélection :");
			rep = sc.nextInt();
			
			switch (rep) {
				case 1:execAlgo1(); break;
				case 2:execAlgo2(); break;
				case 3:execAlgo3(); break;
				case 4:execAlgo4(); break;
				case 5:execAlgo5(); break;
				case 6:execAlgo6(); break;
				case 7:execAlgo7(); break;
				case 8:execAlgo8(); break;
				case 9:try {
					execAlgo9();
				} catch (IOException e) {
					// TODO Bloc catch généré automatiquement
					e.printStackTrace();
				} break;
			}
			
		}while(rep != 0);
		sc.close();
	}

	private static void execAlgo1() {
		// Demander un entier positif et dire s'il est premier ou non
		int i = 0;
		do{			
			System.out.print("Saisissez un nombre entier positif (0 pour quitter) :");
			i = sc.nextInt();
			boolean paspremier = false;
			int curseur = 2;
			while (curseur < i && paspremier == false){
			//for (curseur = 2; curseur < i; curseur++){
				if (i % curseur == 0){
					paspremier = true;
				}
				curseur++;
			}
			if (paspremier == true){
				System.out.println(String.valueOf(i) + " n'est pas premier !");
			}else{
				System.out.println(String.valueOf(i) + " est premier !");
			}
		}while (i>0);
	}

	private static void execAlgo2() {
		// Demander une année et dire si elle est bissextile ou non
		//Depuis l'instauration du calendrier grégorien, sont bissextiles :
		//	1. les années divisibles par 4 mais non divisibles par 100
		//	2. les années divisibles par 400

		int pAnnee = 0;
		do{			
			System.out.print("Saisissez une année (0 pour quitter) :");
			pAnnee = sc.nextInt();
			if (pAnnee%400 == 0 || (pAnnee%4 == 0 && pAnnee%100 != 0)){
				System.out.println(String.valueOf(pAnnee) + " est bissextile !");
			}else{
				System.out.println(String.valueOf(pAnnee) + " n'est pas bissextile !");
			}
		}while (pAnnee>0);
	}

	private static void execAlgo3() {
		// Demander un entier positif et dire s'il est multiple de 3
		int i = 0;
		do{
			System.out.println("Donnez un entier positif (0 pour quitter) :");
			i = sc.nextInt();
			if (i%3 == 0){
				System.out.println(String.valueOf(i) + " est un multiple de 3 !");
			}else{
				System.out.println(String.valueOf(i) + " n'est pas un multiple de 3 !");
			}
		}while (i > 0);
	}

	private static void execAlgo4() {
		// Demander un entier positif supérieur à 27 et donner tous les multiples de 3 et de 5 jusqu'à cette valeur
		int i = 0;
		do{
			System.out.println("Donnez un entier positif supérieur à 27 (0 pour quitter) :");
			i = sc.nextInt();
			if (i <= 27){
				System.out.println("Vous avez saisi une valeur non autorisée !");
			}else{
				String mult3 = new String();
				String mult5 = new String();
				for (int curseur = 28; curseur <= i; curseur++){
					if (curseur%3 == 0){
						mult3 += String.valueOf(curseur) + ", ";
					}
					if (curseur%5 == 0){
						mult5 += String.valueOf(curseur) + ", ";
					}					
				}
				mult3 = (mult3.length() > 2)?mult3.substring(0, mult3.length() - 2):"";
				mult5 = (mult5.length() > 2)?mult5.substring(0, mult5.length() - 2):"";
				System.out.println("Multiples de 3 : " + mult3);
				System.out.println("Multiples de 5 : " + mult5);
			}
		}while (i > 0);		
	}

	private static void execAlgo5() {
		// Demander une chaine de caractères et rechercher le nombre de voyelles qu'elle contient		
		String chaine = "";
		if (sc.hasNextLine()){
			//permet de vider le buffer input car lorsque l'on appuie sur Entrée, 2 caractères existent encore (\r\n)
			//Du coup, cela provoque la lecture en direct du résidus mais pas l'attente d'une nouvelle saisie
			sc.nextLine();
		}
		do{
			System.out.print("Saisissez une chaine de caractère (0 pour quitter) : ");
			chaine = sc.nextLine();
			if (chaine.trim().length() == 0){
				System.out.println("La chaine saisie est vide !");
			}else{
				if (chaine.trim().length() > 1){
					char[] voyelles = {'a', 'e', 'i', 'o', 'u', 'y'};
					int compteur = 0;
					for (int numChar = 0; numChar < chaine.trim().length(); numChar++){
						for (char voyelle : voyelles){
							if (chaine.charAt(numChar) == voyelle){
								compteur++;
							}
						}
					}
					System.out.println("La chaine " + chaine + " contient " + String.valueOf(compteur) + " voyelles !");
				}
			}
		}while (!chaine.trim().equals("0"));		
	}

	private static void execAlgo6() {
		// Palindrome
		String chaine = "";
		if (sc.hasNextLine()){
			//permet de vider le buffer input car lorsque l'on appuie sur Entrée, 2 caractères existent encore (\r\n)
			//Du coup, cela provoque la lecture en direct du résidus mais pas l'attente d'une nouvelle saisie
			sc.nextLine();
		}
		do{
			System.out.print("Saisissez un mot (0 pour quitter) : ");
			chaine = sc.nextLine();
			if (chaine.trim().length() == 0){
				System.out.println("La chaine saisie est vide !");
			}else{
				if (chaine.trim().length() > 1){
					String chaineInversee = "";
					for (int curseur = chaine.length()-1; curseur >= 0; curseur--){
						chaineInversee += chaine.charAt(curseur);
					}
				
					if (chaineInversee.equals(chaine)){
						System.out.println("Le mot est un palindrome !");
					}else{
						System.out.println("Le mot n'est pas un palindrome !");
					}
				}
			}
		}while (!chaine.trim().equals("0"));
	}

	private static void execAlgo7() {
		// Construire la matrice {{1,0,1}, {0,1,0}, {1,1,0}} et générer une matrice negative
		int[][] matricedepart = {{1, 0, 1}, {0, 1, 0}, {1, 1, 0}};
		int[][] matricenegative = new int[3][3];
		
		String chaine = "";
		
		//Affichage de la matrice de départ 
		chaine = "{";
		for (int[] ligne : matricedepart){
			chaine += "{";
			for (int cellule : ligne){
				chaine += cellule + ", ";
			}
			chaine = chaine.substring(0, chaine.length() - 1);
			chaine += "}";
		}
		chaine += "}";
		System.out.println(chaine);
		
		//Mise en négatif de la matrice de départ
		int numLigne = 0;
		for (int[] ligne : matricedepart){
			int numCellule = 0;
			for (int cellule : ligne){
				matricenegative[numLigne][numCellule] = (cellule == 0) ? 1 : 0;
				numCellule++;
			}
			numLigne++;
		}
		
		//Affichage de la matrice générée
		chaine = "{";
		for (int[] ligne : matricenegative){
			chaine += "{";
			for (int cellule : ligne){
				chaine += cellule + ", ";
			}
			chaine = chaine.substring(0, chaine.length() - 1);
			chaine += "}";
		}
		chaine += "}";
		System.out.println(chaine);
	}

	private static void execAlgo8() {
		// Calculatrice
		
	}

	private static void execAlgo9() throws IOException {
		// Fichier CSV
		String lignelue;
		String[] tab;
		List<String[]> tabpersonnes = new ArrayList<String[]>();
		File fic = new File("./fichiers/exemple.csv");
		if (!fic.exists()){
			System.out.println("Le fichier n'existe pas !");
		}else{
		    FileReader fr = new FileReader(fic);
		    BufferedReader br = new BufferedReader(fr);
			do{
				lignelue = br.readLine();
				if (lignelue != null){
					tab = lignelue.split(";");
					tabpersonnes.add(tab);
				}
			}while (lignelue != null);
			br.close();
		}
		for (String[] personne : tabpersonnes){
			System.out.println(personne[0] + " " + personne[1]);
		}
	}
}
