package org.avalone.TPSIO;

public class TP {

	public static void main(String[] args) {

	}
}